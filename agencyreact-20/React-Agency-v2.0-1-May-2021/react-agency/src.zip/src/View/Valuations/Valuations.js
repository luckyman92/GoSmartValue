import React,{useState} from 'react';
// import {Link} from 'react-router-dom';
// import classnames from 'classnames';

import Valuation from '../../Element/Valuation';

const Valuations = (props) => {

  return(
    <Valuation />
	)
}

export default Valuations;